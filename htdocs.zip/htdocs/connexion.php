<?php
      try{
        $pdo= new PDO("mysql:host=localhost;dbname=bookexchange","root","root");
    }
    catch(PDOException $e){
                echo $e->getMessage();
    }

        $ins=$pdo->prepare("insert into users(FullName,Mail,Password) values(?,?,?)");
        $ins->execute(array($FullName,$Mail,md5($Password)));
     

?>