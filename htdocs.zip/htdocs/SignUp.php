<?php

  $nom=$_POST['FullName'];
  $mail=$_POST['Mail'];
  $password=$_POST['Password'];
  $repeatpassword=$_POST['repeatpassword'];
  $valider=$_POST['valider'];
  $message="";
  // if(empty($nom))$message="Name invalide";
  // if(empty($mail))$message="Email invalide";
  // if(empty($password))$message="Password invalide";
  if($password!=$repeatpassword)$message="password isn't not password confirmed";
  if(empty($message))
  {
    include("connexion.php");
    $req=$pdo->prepare("select id from users where Mail=? limit 1");
    $req->setFetchMode(PDO::FETCH_ASSOC);
    $req->execute(array($mail));
    $tab=$req->fetchAll();
    if(count($tab)>0)
    {
        $message="this exist yet!";
      ?>
      <script LANGUAGE="javascript">  alert("<?php echo("$message");?>");</script>
    <?php
    }
    else{
      $ins=$pdo->prepare("insert into users(FullName,Mail,Password) values(?,?,?)");
      $ins->execute(array($nom,$mail,md5($password)));
      
    }
  }
  else{
    ?>
    <script LANGUAGE="javascript">  alert("<?php echo("$message");?>");</script>
  <?php
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"></link>
            <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
            <link rel="stylesheet" href="Css/SignUp.css"/>
            <meta charset="UTF-8">
    <title>SignUp</title>
</head>


  


<body class="bodySignUp">

    <div class="classSignUp " > 
        <a href="Acceuil.html"><div class="SignUplogo"></div></a>
                  <form class="formedit" action="SignUp.php" method="POST">
                        <div class="form-group">
                          <input type="text" class="form-control" name="FullName" id="FullName"  placeholder="Full Name"></input>
                        </div>
                        <div class="form-group">
                          <input type="email" class="form-control" name="Mail" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"></input>
                        </div>
                       <div>
                        <div class="form-group" id ="IdpassWord">
                            <input type="password"  class="form-control" name="Password" id="exampleInputPassword1" placeholder="Password"></input>
                          </div>
                          <div class="form-group" id ="IdpassWordConfirm">
                            <input type="password"  class="form-control" name="repeatpassword" id="exampleInputPassword2" placeholder="Confirm Password"></input>
                          </div>
                       </div>

                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1"></input>
                            <label class="form-check-label" id="IdCheckbox" for="exampleCheck1">I agree to receive instructional and promotional emails</label>
                        </div>
                        <button  id="idSignUp" name="valider"> Sign Up </button>
                        
                  </form>
                  <div class="Li1orLi2">
                    <div class="ClassLine1">
                        <hr width="100%" color="gray" align="left">
                    </div> 
                    <div class="ClassLine2">
                        <hr width="100%" color="gray" align="right">
                    </div>
                    <div class="ClassOrSingUp">
                        <h7>Or Sign Up with</h7>
                    </div>
                </div>
                  <div class="ClassSignWith">

                      <div class="SignWithCountClass">
                        <div class="ClasslogoINPT"></div>
                        <div class="ClassNameinpt">INPT Count</div>
                      </div>
                      <div class="SignWithGmail">
                          <div class="ClasslogoGmail"></div>
                          <div class="ClassNamegmail">Gmail Count </div>
                      </div>
                  </div>
    </div>
</body>
</html>
