<?php
  $mail=$_POST['Mail'];
  $password=$_POST['Password'];
  $valider=$_POST['valider'];
  
  $message="";
  if(isset($valider)){
    include("connexion.php");
    $req=$pdo->prepare("select * from users where Mail=? and Password=? limit 1");
    $sql =$pdo->prepare( "select FullName from users where Mail=$mail ");
    // $result = $pdo->query($sql);
    $req->setFetchMode(PDO::FETCH_ASSOC);
    $req->execute(array($mail,md5($password)));
    $tab=$req->fetchAll();
    if(count($tab)==0){
      $message="Login or password incorrect!";
      ?>
      <script LANGUAGE="javascript">  alert("<?php echo("$message");?>");</script>
    <?php
    }else{
      $req=$pdo->prepare("select * from users where Mail=? and Password=? limit 1");
      $req->setFetchMode(PDO::FETCH_ASSOC);
      $req->execute(array($mail,md5($password)));
      $tab=$req->fetchAll();
      $message="welcome "+$tab[0]["FullName"];
      ?>
      <script LANGUAGE="javascript">  
        alert("Welcome JARMOUNE Mohamed");
      //  <a href="welcome.php">;
     
    </script>
    
    <?php
   
    }
  }


?>

<!DOCTYPE html>
<html lang="en">
<head>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"></link>
            <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
            <link rel="stylesheet" href="Css/Login.css"/>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body class="bodyLogin">
    <div class="moinscri"> 
                   <a href="Acceuil.html"><div class="logoLogin"></div></a>
                  <form class="formedit"action="login1.php" method="POST">
                        <div class="form-group">
                          <input type="email" class="form-control"name="Mail" id="LoginInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"></input>
                        </div>
                        <div class="form-group" id ="labelpassword">
                          <input type="password"class="form-control" name="Password" id="LoginInputPassword1" placeholder="Password"></input>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" name="valider" id="submitmarginLogin">Log in</button>
                  </form>
                  <div class="ForgotPassword">
                    Forgot Password?
                  </div>

                  <div class="ClassLoginWith">
                    <a href="SignUp.php">
                    <div class="LoginWithCountClass">
                      <div class="ClasslogoINPTLogin"></div>
                      <div class="ClassNameinptLogin">Creat An Account</div>
                    </div>
                    </a>
                    <div class="LoginWithGmail">
                        <div class="ClasslogoGmailLogin"></div>
                        <div class="ClassNamegmailLogin">Log in with gmail </div>
                    </div>
                </div>
              </div>
</body>
</html>